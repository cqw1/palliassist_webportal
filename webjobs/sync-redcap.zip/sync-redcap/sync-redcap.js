var request = require('request');
var url = 'https://palliassist-dev-us.azurewebsites.net/sync-redcap';

request.post(url, {});
