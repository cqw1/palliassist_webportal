"""Auto-generated file, do not edit by hand. 352 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_352 = [NumberFormat(pattern='(\\d{2})(\\d{3})(\\d{3})', format='\\1 \\2 \\3')]
