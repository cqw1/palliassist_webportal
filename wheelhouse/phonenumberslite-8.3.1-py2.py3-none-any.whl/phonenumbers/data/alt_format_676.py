"""Auto-generated file, do not edit by hand. 676 metadata"""
from ..phonemetadata import NumberFormat

PHONE_ALT_FORMAT_676 = [NumberFormat(pattern='(\\d{2})(\\d{5})', format='\\1 \\2', leading_digits_pattern=['7[5-9]|8[47-9]'])]
